<?php
namespace ZFToolTest\Diagnostics\TestAsset;

use ZendDiagnostics\Result\AbstractResult;

class UnknownResult extends AbstractResult
{
}
