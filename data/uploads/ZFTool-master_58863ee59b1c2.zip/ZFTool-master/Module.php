<?php
/**
 * This file is placed here for compatibility with Zendframework's ModuleManager.
 * It allows usage of this module even without composer.
 * The original Module.php lives in 'src' directory in order to respect PSR-0
 */
require_once __DIR__ . '/src/ZFTool/Module.php';
